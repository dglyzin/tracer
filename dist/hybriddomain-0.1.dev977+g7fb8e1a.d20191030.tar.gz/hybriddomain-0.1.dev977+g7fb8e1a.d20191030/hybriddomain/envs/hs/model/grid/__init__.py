'''model.grid.__init__'''
