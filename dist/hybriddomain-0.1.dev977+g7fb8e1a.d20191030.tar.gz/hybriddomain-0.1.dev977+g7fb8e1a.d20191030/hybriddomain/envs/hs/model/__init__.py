'''Model represent branch of methods for work with
pde task: It contain equation, initial and bound regions,
solvers params. It can be loaded from json file or
created using oop aproach.

See ``envs/hs/doc/`` for examples.
'''
