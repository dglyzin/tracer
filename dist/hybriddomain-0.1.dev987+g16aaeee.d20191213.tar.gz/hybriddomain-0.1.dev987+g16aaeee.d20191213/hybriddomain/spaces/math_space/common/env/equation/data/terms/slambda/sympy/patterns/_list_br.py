terms_br_gens = dict([
    ('func', lambda func, sympy: lambda A: sympy.simplify(func)(A))])
