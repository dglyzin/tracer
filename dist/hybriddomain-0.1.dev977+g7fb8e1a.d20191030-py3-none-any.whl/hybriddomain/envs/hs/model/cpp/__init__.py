'''model.cpp.__init__.py'''
