'''Generators transform model to cpp (using templates
``gens/hs/templates``) and dom (using numpy arrays) files
It also create sh runner. All this stuff will be in
``problems/problem_folder/out`` folder.'''
